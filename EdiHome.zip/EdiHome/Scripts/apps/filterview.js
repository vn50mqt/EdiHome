﻿var KoModel = function(viewModel) {
    var self = this;
    self.isLoaded = ko.observable(false);

    self.countries = ko.observableArray([]);
    self.cultures = ko.observableArray([]);

    self.originalCulture = viewModel.OriginalCulture;
    self.selectedCulture = ko.observable(viewModel.SelectedCulture);
    self.selectedCountry = ko.observable(viewModel.SelectedCountry);

    $.each(viewModel.Countries, function (index, countryModel) {
        if (countryModel.CountryCode !== "ZZ") {
            self.countries.push(new GenericDisplayOption(countryModel.CountryDescription, countryModel.CountryCode));
        }
    });

    $.each(viewModel.Cultures, function (index, cultureModel) {
        self.cultures.push(new GenericDisplayOption(cultureModel, cultureModel));
    });

    self.setFilters = function() {
        Cookies.set("filterViewCulture", self.selectedCulture());
        Cookies.set("filterViewCountry", self.selectedCountry());
        window.location = $("#home").val();
    }

    self.isLoaded(true);
}


//builds a generic value/display drop down option
function GenericDisplayOption(display, value) {
    var self = this;

    self.display = display;
    self.value = value;
}
