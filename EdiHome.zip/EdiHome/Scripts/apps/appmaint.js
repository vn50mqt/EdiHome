﻿var KoModel = function(viewModel) {
    var self = this;
    self.isEdit = viewModel.isEdit;
    self.isLoaded = ko.observable(false);
    self.allApplications = ko.observableArray([]);
    self.appId = viewModel.AppId;
    self.appHistoryId = ko.observable("");
    self.appTranslations = ko.observableArray([]);
    self.appPath = ko.observable(viewModel.AppPath);
    self.attachedDocuments = ko.observableArray([]);
    self.docCultures = ko.observableArray([]);
    self.developerAppName = ko.observable(viewModel.IsAdd ? $("#PlaceHolderAppNameLbl").val() : viewModel.DeveloperAppName);
    self.displayLastModifiedMessage = ko.observable(viewModel.IsEdit);
    self.errorMessage = ko.observable("");
    self.fileUploadErrorMessage = ko.observable("");
    self.fileUploadHasError = ko.observable(false);
    self.formDataSupported = ko.observable(true);
    self.globalCultures = [];
    self.hasHistory = ko.observable(viewModel.AppHistory.length > 0);
    self.historyList = ko.observableArray([]);
    self.lastModifyUserId = ko.observable(viewModel.LastModifyUserId);
    self.lastModifyTs = ko.observable(new Date(Date.parse(viewModel.LastModifyTs)));
    self.selectedDisplayExternally = ko.observable(viewModel.SelectedDisplayExternally);
    self.selectedCulture = ko.observable("");
    self.yesNoOptions = ko.observableArray([]);


    //css observables
    self.validAppDetailTranslationClassName = ko.observable("");
    self.validAppPathClassName = ko.observable("");

    self.appPathClassName = ko.observable("");

    //yes/no dropdown
    self.yesNoOptions.push(new GenericDisplayOption($("#NoLbl").val(), false));
    self.yesNoOptions.push(new GenericDisplayOption($("#YesLbl").val(), true));

    //tooltips
    self.displayExternalTooltip = ko.observable($("#DisplayExternalTooltipMsg").val());
    self.displayAppPathTooltip = ko.observable($("#DisplayAppPathTooltipMsg").val());
    self.documentTooltip = ko.observable($("#DocumentTooltipMsg").val());
    self.documentAddTooltip = ko.observable($("#DocumentAddTooltipMsg").val());

    //generate the translations for the app name
    if (viewModel.AppTranslations.length === 0) {
        self.appTranslations.push(new BuildTranslation(true, true, self, null));
    } else {

        $.each(viewModel.AppTranslations, function (index, translationModel) {
            var isFirst = translationModel.Culture === "en-us";
            self.appTranslations.push(new BuildTranslation(isFirst, false, self, translationModel));
        });
        
    }

    if (viewModel.AllApps.length > 0) {
        $.each(viewModel.AllApps, function (index, appModel) {
            self.allApplications.push(new BuildNewApplicationEditList(appModel));
        });
    }

    //load the history
    $.each(viewModel.AppHistory, function (index, historyModel) {
        self.historyList.push(new BuildHistoryObject(historyModel));
    });

    //load any attached document info
    $.each(viewModel.AttachedDocuments, function (index, docModel) {
        self.attachedDocuments.push(new AttachedDocumentObject(null, self, docModel, false));
    });

    ////load global cultures
    self.globalCultures.push(new GenericDisplayOption("", ""));
    $.each(viewModel.GlobalCultures, function (index, cultureModel) {
        self.globalCultures.push(new GenericDisplayOption(cultureModel, cultureModel));
    });

    //add the app name translation
    self.addAppTranslation = function () {
        self.appTranslations.push(new BuildTranslation(false, true, self, null));
    }

    //remove the app name translation
    self.removeAppTranslation = function (translation) {
        self.appTranslations.remove(translation);

        var cultureExists = jQuery.grep(self.appTranslations(), function (e) {
            return e.culture() === translation.culture();
        });

        //if the culture doesn't exist, then and only then remove the document (this will prevent accidental deletion when adding new lines where the culture matched and removing it before changing culture)
        if (cultureExists === undefined || cultureExists === null || cultureExists.length === 0) {
            var toDelete = jQuery.grep(self.attachedDocuments(), function (e) {
                return e.culture === translation.culture();
            });

            //must remove the document associated with the culture if the culture based translation is removed
            if (toDelete !== undefined && toDelete !== null && toDelete.length > 0) {
                self.attachedDocuments.remove(toDelete[0]);
            }
        }
        

        //re-validate each culture on delete, set error to false
        $.each(self.appTranslations(), function (index, appKo) {
            appKo.cultureIsDuplicate(false);
        });

        var badTranslations = jQuery.grep(self.appTranslations(), function (e) {
            return translation.culture() === e.culture();
        });

        //if any bad entries, set error to true
        if (badTranslations !== undefined && badTranslations !== null && badTranslations.length > 1) {
            $.each(badTranslations, function (index, appKo) {
                appKo.cultureIsDuplicate(true);
            });
        }

    }

    //save the app settings
    self.saveApp = function () {
        $.ajax({
            type: "Post",
            url: $("#savePath").val(),
            data: {
                appDetails: ko.toJSON(self),
                appId: self.appId,
                historyId: self.appHistoryId()
            },
            datatype: "json"
        })
        .done(function (result) {
            if (!result.HasFailure) {
                self.lastModifyUserId(result.LastModifyUserId);
                //have to parse it like this due to how it's passed through the JsonResult
                self.lastModifyTs(new Date(result.LastModifyTs.match(/\d+/)[0] * 1));
                if (self.appId !== 0) {
                    self.refreshHistory();
                } else {
                    $("#successModal").modal("toggle");
                }
            } else {
                self.errorMessage($("#AppSaveDetailsErrorMsg").val());
                $("#errorModal").modal("show");
            }
        })
        .fail(function (result) {
            self.errorMessage($("#AppSaveDetailsErrorMsg").val());
            $("#errorModal").modal("show");
        });
    }

    //load a specific instance of the application configurations
    self.loadHistoricalAppEntry = function (data) {
        //reset lists
        self.appTranslations([]);
        self.attachedDocuments([]);

        self.appPath(data.viewModel.AppPath);
        self.lastModifyUserId(data.lastModifyUserId);
        self.lastModifyTs(new Date(Date.parse(data.lastModifyTs)));
        self.selectedDisplayExternally(data.viewModel.SelectedDisplayExternally);
        self.appHistoryId(data.appHistoryId);


        $.each(data.viewModel.AppTranslations, function (index, translationModel) {
            var isFirst = translationModel.Culture === "en-us";
            self.appTranslations.push(new BuildTranslation(isFirst, false, self, translationModel));
        });

        //load any attached document info
        $.each(data.viewModel.AttachedDocuments, function (index, docModel) {
            self.attachedDocuments.push(new AttachedDocumentObject(null, self, docModel, false));
        });

        $("#historyModal").modal("toggle");
    };

    //this is the easiest way to refresh the history, but reloading the current maintenance screen
    self.refreshHistory = function() {
        window.location = $("#refreshUrl").val();
    }

    //open the modal
    self.toggleHistoryModal = function () {
        $("#historyModal").modal("toggle");
    }

    //redirect to new add page
    self.addNewApplication = function () {
        window.location = $("#addNewAppUrl").val();
    }

    //delete the document attached
    self.deleteAttachedDocument = function(data) {
        self.attachedDocuments.remove(data);
    }

    self.loadApplicationForEdit = function(data) {
        var editUrl = $("#editAppUrl").val().replace("idTest", data.appId);
        window.location = editUrl;
    }

    self.deleteApplicationFromDb = function(data) {
        $.ajax({
            type: "Post",
            url: $("#deleteAppUrl").val(),
            data: {
                appId: data.appId
            },
            datatype: "json"
        })
        .done(function (result) {
            if (result) {
                window.location = $("#addNewAppUrl").val();
            } else {
                self.errorMessage($("#AppDeleteDetailsErrorMsg").val());
                $("#errorModal").modal("show");
            }
        })
        .fail(function (result) {
            self.errorMessage($("#AppDeleteDetailsErrorMsg").val());
            $("#errorModal").modal("show");
        });
    }

    //will handle the file upload converter from binary to base64 string so it can be embedded in the xml or json and verify the type and size
    if (typeof window.FormData !== "undefined") {

        self.fileUploadErrorMessage("");

        $("#fileParent").on("change", "#documentPicker", function (event) {
            var file = event.target.files[0];
            if (file) {

                $("#waitModal").modal("show");
                //set the form data
                var formData = new FormData();
                formData.append("appDocumentation", file);
                formData.append("culture", self.selectedCulture());

                $.ajax({
                    url: $("#fileHandler").val(),
                    type: "POST",
                    data: formData,
                    cache: false,
                    contentType: false,
                    processData: false
                }).done(function (result) {
                    if (result.Success) {
                        self.fileUploadHasError(false);
                        self.fileUploadErrorMessage("");

                        var isCultureAttached = jQuery.grep(self.attachedDocuments(), function (e) {
                            return e.culture === self.selectedCulture();
                        });

                        if (isCultureAttached !== undefined && isCultureAttached !== null && isCultureAttached.length > 0) {
                            self.attachedDocuments.remove(isCultureAttached[0]);
                        }

                        self.attachedDocuments.push(new AttachedDocumentObject(file.name, self, result, true));

                    } else {
                        self.fileUploadHasError(true);

                        if (result.Reason === "WrongType") {
                            self.fileUploadErrorMessage($("#WrongTypeMsg").val());
                        } else if (result.Reason === "ToLarge") {
                            self.fileUploadErrorMessage($("#ToLargeMsg").val());
                        } else if (result.Reason === "FileMissing") {
                            self.fileUploadErrorMessage($("#FileMissingMsg").val());
                        } else if (result.Reason === "MissingCulture") {
                            self.fileUploadErrorMessage($("#MissingCultureMsg").val());
                        }

                    }
                }).fail(function (result) {
                    self.fileUploadHasError(true);
                    self.fileUploadErrorMessage($("#ErrorUploadingFileLbl").val());
                }).always(function () {
                    $("#waitModal").modal("hide");
                    event.target.files = null;

                    $("#documentPicker").remove();
                    $("#fileParent").prepend('<input type="file" id="documentPicker" name="file" />');
                    self.selectedCulture("");
                });
            };
        });

    } else if (typeof window.FormData === "undefined") {
        self.formDataSupported(false);
        self.fileUploadErrorMessage($("#FileNotSupportedLbl").val());
        self.fileUploadHasError(true);
    }


    //generates the list of cultures
    self.buildDocCultures = ko.computed(function () {
        self.docCultures([]);

        var valid = jQuery.grep(self.appTranslations(), function (e) {
            return e.translationObjectValid();
        }); 

        if (valid !== undefined && valid !== null && valid.length !== 0) {
            $.each(valid, function (index, appKo) {
                if (appKo.translationObjectValid()) {
                    self.docCultures.push(new GenericDisplayOption(appKo.culture(), appKo.culture()));
                }
            });
        }
    });

    //check the app path 
    self.appPathValid = ko.computed(function () {
        if (self.appPath() === "") {
            self.validAppPathClassName(GetFormIconClass(false));
            self.appPathClassName(GetFormClass(false));
            return false;
        }

        //if (self.selectedDisplayExternally()) {
        //    //need to verify no hardcoded paths are present

        //    var regex = new RegExp(/^(?!www\.|(?:http|ftp)s?:\/\/|[A-Za-z]:\\|\/\/).*/gm);
        //    var regexPass = regex.test(self.appPath());
        //    if (!regexPass) {
        //        self.validAppPathClassName(GetFormIconClass(false));
        //        self.appPathClassName(GetFormClass(false));
        //        return false;
        //    }
        //}

        self.validAppPathClassName(GetFormIconClass(true));
        self.appPathClassName(GetFormClass(true));
        return true;
    });

    //title for the question (mostly for developer use)
    self.appName = ko.computed(function () {
        if ($.trim(self.appTranslations()[0].appNameTranslation()) === "") {
            self.developerAppName($("#PlaceHolderAppNameLbl").val());
        } else {
            self.developerAppName(self.appTranslations()[0].appNameTranslation());
        }
    });

    //are all of the app name translations valid?
    self.appTranslationsValid = ko.computed(function () {
        var translationsNotValid = jQuery.grep(self.appTranslations(), function (e) {
            if (!e.translationObjectValid()) {
                return true;
            }
            return false;
        });

        if (translationsNotValid.length > 0) {
            self.validAppDetailTranslationClassName(GetFormIconClass(false));
            return false;
        }

        self.validAppDetailTranslationClassName(GetFormIconClass(true));
        return true;
    });

    //is the app valid and able to save
    self.appValid = ko.computed(function () {
        if (!self.appPathValid()) {
            return false;
        }

        if (!self.appTranslationsValid()) {
            return false;
        }

        return true;

    });

    self.isLoaded(true);

}

//application edit list
function BuildNewApplicationEditList(appModel) {
    var self = this;

    self.appId = appModel.AppId;
    self.lastModifyUserId = appModel.LastModifyUserId;
    self.lastModifyTs = appModel.LastModifyTs;
    self.appNameTranslation = appModel.AppNameTranslation;
}


//build out the attached document object
function AttachedDocumentObject(fileName, rootKo, docModel, isNew) {
    var self = this;
    self.appId = rootKo.appId;
    self.base64Encoded = docModel.Base64Encoded;
    self.fileName = fileName === null ? docModel.FileName : fileName;
    self.contentType = docModel.ContentType;
    self.culture = docModel.Culture !== null && docModel.Culture !== undefined ? docModel.Culture : rootKo.selectedCulture();
    self.guid = docModel.Guid;

    if (rootKo.appHistoryId() !== "") {
        self.href = $("#downloadUrl").val().replace("cultureTest", self.culture).replace("idTest", rootKo.appHistoryId()).replace("versionTest", "archive");
    } else {
        self.href = $("#downloadUrl").val().replace("cultureTest", self.culture).replace("idTest", self.appId).replace("versionTest", "release");
    }
   


    self.isNew = isNew;
}


//builds the translation section for each translation area
function BuildTranslation(isFirst, isManual, rootKo, translationModel) {
    var self = this;

    self.isFirst = isFirst;
    self.cultures = rootKo.globalCultures;
    self.culture = ko.observable(isManual && isFirst ? "en-us" : isManual ? "" : translationModel.Culture);
    self.isManual = ko.observable(isManual && !isFirst);
    self.appNameTranslation = ko.observable(isManual ? "" : translationModel.AppNameTranslation);
    self.appDescTranslation = ko.observable(isManual ? "" : translationModel.AppDescTranslation);
    self.cultureIsDuplicate = ko.observable(false);

    //statics
    self.cultureLocked = self.culture().toLowerCase() === "en-us";

    //css class names
    self.cultureClassName = ko.observable("");
    self.appDescTranslationClassName = ko.observable("");
    self.appNameTranslationClassName = ko.observable("");
    self.validAppDetailTranslationClassName = ko.observable("");

    //make an input readonly
    self.inputReadonlyState = function () {
        if (!self.cultureLocked) {
            return undefined;
        } else {
            return "readonly";
        }
    }

    //this will handle the error checking for duplicate cultures
    self.culture.subscribe(function (data) {

        $.each(rootKo.appTranslations(), function (index, appKo) {
            appKo.cultureIsDuplicate(false);
        });

        var badTranslations = jQuery.grep(rootKo.appTranslations(), function (e) {
            return data === e.culture();
        });

        if (badTranslations !== undefined && badTranslations !== null && badTranslations.length > 1) {
            $.each(badTranslations, function (index, appKo) {
                appKo.cultureIsDuplicate(true);
            });
        }
    });

    //is the culture entered valid?
    self.cultureValid = ko.computed(function () {
        if ($.trim(self.culture()) === "") {
            self.cultureClassName(GetFormClass(false));
            return false;
        }

        //if entered, validate, must match xx-xx lower case only
        var m = self.culture().match(/^[a-z]{2}-[a-z]{2}$/);
        if (m === null) {
            self.cultureClassName(GetFormClass(false));
            return false;
        }

        if (self.cultureIsDuplicate()) {
            self.cultureClassName(GetFormClass(false));
            return false;
        }

        self.cultureClassName(GetFormClass(true));
        return true;

    });

    //is the entered translation valid?
    self.appNameTranslationValid = ko.computed(function () {
        if ($.trim(self.appNameTranslation()) === "") {
            self.appNameTranslationClassName(GetFormClass(false));
            return false;
        }

        self.appNameTranslationClassName(GetFormClass(true));
        return true;

    });

    //is the entered translation valid?
    self.appDescTranslationValid = ko.computed(function () {
        if ($.trim(self.appDescTranslation()) === "") {
            self.appDescTranslationClassName(GetFormClass(false));
            return false;
        }

        self.appDescTranslationClassName(GetFormClass(true));
        return true;

    });


    //is the entire translation object valid
    self.translationObjectValid = ko.computed(function () {
        if (!self.cultureValid()) {
            self.validAppDetailTranslationClassName(GetFormIconClass(false));
            return false;
        }

        if (!self.appNameTranslationValid()) {
            self.validAppDetailTranslationClassName(GetFormIconClass(false));
            return false;
        }

        if (!self.appDescTranslationValid()) {
            self.validAppDetailTranslationClassName(GetFormIconClass(false));
            return false;
        }

        self.validAppDetailTranslationClassName(GetFormIconClass(true));
        return true;
    });
}


//generate the object that holds the entire history model
function BuildHistoryObject(historyModel) {
    var self = this;
    self.viewModel = historyModel.AppModel;
    self.appId = historyModel.AppId;
    self.appHistoryId = historyModel.AppHistoryId;
    self.lastModifyUserId = $.trim(historyModel.LastModifyUserId);
    self.lastModifyTs = historyModel.LastModifyTs;
    self.selectedDisplayExternally = historyModel.SelectedDisplayExternally;

}

//builds a generic value/display drop down option
function GenericDisplayOption(display, value) {
    var self = this;

    self.display = display;
    self.value = value;
}

//function that handles the form field validation class names
function GetFormClass(isValid) {
    if (isValid) {
        return "form-control";
    }

    return "form-control is-invalid";
}

//function that handles the form field validation icon class names
function GetFormIconClass(isValid) {
    if (isValid) {
        return "fa fa-check text-success";
    }

    return "fa fa-exclamation-triangle text-danger";
}