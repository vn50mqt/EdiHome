﻿var KoModel = function (viewModel) {
    var self = this;
    self.isEdit = viewModel.isEdit;
    self.isLoaded = ko.observable(false);
    self.allLetters = ko.observableArray([]);
    self.letterId = viewModel.LetterId;
    self.letterHistoryId = ko.observable("");
    self.letterTranslations = ko.observableArray([]);
    self.attachedDocuments = ko.observableArray([]);
    self.docCultures = ko.observableArray([]);
    self.developerLetterName = ko.observable(viewModel.IsAdd ? $("#PlaceHolderLetterNameLbl").val() : viewModel.DeveloperLetterName);
    self.displayLastModifiedMessage = ko.observable(viewModel.IsEdit);
    self.errorMessage = ko.observable("");
    self.fileUploadErrorMessage = ko.observable("");
    self.fileUploadHasError = ko.observable(false);
    self.formDataSupported = ko.observable(true);
    self.globalCultures = [];
    self.hasHistory = ko.observable(viewModel.LetterHistory.length > 0);
    self.historyList = ko.observableArray([]);
    self.lastModifyUserId = ko.observable(viewModel.LastModifyUserId);
    self.lastModifyTs = ko.observable(new Date(Date.parse(viewModel.LastModifyTs)));
    self.selectedCulture = ko.observable("");
    self.yesNoOptions = ko.observableArray([]);


    self.workPostedDate = ko.observable(viewModel.WorkPostedDate);
    self.postedDate = ko.observable(moment(self.workPostedDate()).format("YYYY-MM-DD HH:mm"));


    //css observables
    self.validLetterDetailTranslationClassName = ko.observable("");
    self.validLetterDetailsClassName = ko.observable("");
    self.validPostedDateClassName = ko.observable("");
    self.validAttachedDocumentsClassName = ko.observable("");

    //css observables (input highlight)
    self.postedDateClassName = ko.observable("");

    //yes/no dropdown
    self.yesNoOptions.push(new GenericDisplayOption($("#NoLbl").val(), false));
    self.yesNoOptions.push(new GenericDisplayOption($("#YesLbl").val(), true));

    //tooltips
    self.documentTooltip = ko.observable($("#DocumentLetterTooltipMsg").val());
    self.documentAddTooltip = ko.observable($("#DocumentLetterAddTooltipMsg").val());
    self.displayPostedDateTooltip = ko.observable($("#DisplayPostedDateTooltipMsg").val());


    //generate the translations for the app name
    if (viewModel.LetterTranslations.length === 0) {
        self.letterTranslations.push(new BuildTranslation(true, true, self, null));
    } else {

        $.each(viewModel.LetterTranslations, function (index, translationModel) {
            var isFirst = translationModel.Culture === "en-us";
            self.letterTranslations.push(new BuildTranslation(isFirst, false, self, translationModel));
        });

    }

    if (viewModel.AllLetters.length > 0) {
        $.each(viewModel.AllLetters, function (index, letterModel) {
            self.allLetters.push(new BuildNewLetterEditList(letterModel));
        });
    }

    //load the history
    $.each(viewModel.LetterHistory, function (index, historyModel) {
        self.historyList.push(new BuildHistoryObject(historyModel));
    });

    //load any attached document info
    $.each(viewModel.AttachedDocuments, function (index, docModel) {
        self.attachedDocuments.push(new AttachedDocumentObject(null, self, docModel, false));
    });

    ////load global cultures
    self.globalCultures.push(new GenericDisplayOption("", ""));
    $.each(viewModel.GlobalCultures, function (index, cultureModel) {
        self.globalCultures.push(new GenericDisplayOption(cultureModel, cultureModel));
    });

    //add the app name translation
    self.addLetterTranslation = function () {
        self.letterTranslations.push(new BuildTranslation(false, true, self, null));
    }

    //remove the app name translation
    self.removeLetterTranslation = function (translation) {
        self.letterTranslations.remove(translation);

        var cultureExists = jQuery.grep(self.letterTranslations(), function (e) {
            return e.culture() === translation.culture();
        });

        //if the culture doesn't exist, then and only then remove the document (this will prevent accidental deletion when adding new lines where the culture matched and removing it before changing culture)
        if (cultureExists === undefined || cultureExists === null || cultureExists.length === 0) {
            var toDelete = jQuery.grep(self.attachedDocuments(), function (e) {
                return e.culture === translation.culture();
            });

            //must remove the document associated with the culture if the culture based translation is removed
            if (toDelete !== undefined && toDelete !== null && toDelete.length > 0) {
                self.attachedDocuments.remove(toDelete[0]);
            }
        }


        //re-validate each culture on delete, set error to false
        $.each(self.letterTranslations(), function (index, letterKo) {
            letterKo.cultureIsDuplicate(false);
        });

        var badTranslations = jQuery.grep(self.letterTranslations(), function (e) {
            return translation.culture() === e.culture();
        });

        //if any bad entries, set error to true
        if (badTranslations !== undefined && badTranslations !== null && badTranslations.length > 1) {
            $.each(badTranslations, function (index, letterKo) {
                letterKo.cultureIsDuplicate(true);
            });
        }

    }

    //save the app settings
    self.saveLetter = function () {
        $.ajax({
            type: "Post",
            url: $("#savePath").val(),
            data: {
                letterDetails: ko.toJSON(self),
                letterId: self.letterId,
                historyId: self.letterHistoryId()
            },
            datatype: "json"
        })
            .done(function (result) {
                if (!result.HasFailure) {
                    self.lastModifyUserId(result.LastModifyUserId);
                    //have to parse it like this due to how it's passed through the JsonResult
                    self.lastModifyTs(new Date(result.LastModifyTs.match(/\d+/)[0] * 1));
                    if (self.letterId !== 0) {
                        self.refreshHistory();
                    } else {
                        $("#successModal").modal("toggle");
                    }
                } else {
                    self.errorMessage($("#SaveLetterDetailsErrorMsg").val());
                    $("#errorModal").modal("show");
                }
            })
            .fail(function (result) {
                self.errorMessage($("#SaveLetterDetailsErrorMsg").val());
                $("#errorModal").modal("show");
            });
    }

    //load a specific instance of the application configurations
    self.loadHistoricalLetterEntry = function (data) {
        //reset lists
        self.letterTranslations([]);
        self.attachedDocuments([]);

        self.lastModifyUserId(data.lastModifyUserId);
        self.lastModifyTs(new Date(Date.parse(data.lastModifyTs)));
        self.letterHistoryId(data.letterHistoryId);


        $.each(data.viewModel.LetterTranslations, function (index, translationModel) {
            var isFirst = translationModel.Culture === "en-us";
            self.letterTranslations.push(new BuildTranslation(isFirst, false, self, translationModel));
        });

        //load any attached document info
        $.each(data.viewModel.AttachedDocuments, function (index, docModel) {
            self.attachedDocuments.push(new AttachedDocumentObject(null, self, docModel, false));
        });

        $("#historyModal").modal("toggle");
    };

    //this is the easiest way to refresh the history, but reloading the current maintenance screen
    self.refreshHistory = function () {
        window.location = $("#refreshUrl").val();
    }

    //open the modal
    self.toggleHistoryModal = function () {
        $("#historyModal").modal("toggle");
    }

    //redirect to new add page
    self.addNewLetter = function () {
        window.location = $("#addNewLetterUrl").val();
    }

    //delete the document attached
    self.deleteAttachedDocument = function (data) {
        self.attachedDocuments.remove(data);
    }

    self.loadLetterForEdit = function (data) {
        var editUrl = $("#editLetterUrl").val().replace("idTest", data.letterId);
        window.location = editUrl;
    }

    self.deleteLetterFromDb = function (data) {
        $.ajax({
            type: "Post",
            url: $("#deleteLetterUrl").val(),
            data: {
                letterId: data.letterId
            },
            datatype: "json"
        })
            .done(function (result) {
                if (result) {
                    window.location = $("#addNewLetterUrl").val();
                } else {
                    self.errorMessage($("#DeleteLetterDetailsErrorMsg").val());
                    $("#errorModal").modal("show");
                }
            })
            .fail(function (result) {
                self.errorMessage($("#DeleteLetterDetailsErrorMsg").val());
                $("#errorModal").modal("show");
            });
    }

    //will handle the file upload converter from binary to base64 string so it can be embedded in the xml or json and verify the type and size
    if (typeof window.FormData !== "undefined") {

        self.fileUploadErrorMessage("");

        $("#fileParent").on("change", "#documentPicker", function (event) {
            var file = event.target.files[0];
            if (file) {

                $("#waitModal").modal("show");
                //set the form data
                var formData = new FormData();
                formData.append("letterDocumentation", file);
                formData.append("culture", self.selectedCulture());

                $.ajax({
                    url: $("#fileHandler").val(),
                    type: "POST",
                    data: formData,
                    cache: false,
                    contentType: false,
                    processData: false
                }).done(function (result) {
                    if (result.Success) {
                        self.fileUploadHasError(false);
                        self.fileUploadErrorMessage("");

                        var isCultureAttached = jQuery.grep(self.attachedDocuments(), function (e) {
                            return e.culture === self.selectedCulture();
                        });

                        if (isCultureAttached !== undefined && isCultureAttached !== null && isCultureAttached.length > 0) {
                            self.attachedDocuments.remove(isCultureAttached[0]);
                        }

                        self.attachedDocuments.push(new AttachedDocumentObject(file.name, self, result, true));

                    } else {
                        self.fileUploadHasError(true);

                        if (result.Reason === "WrongType") {
                            self.fileUploadErrorMessage($("#WrongTypeMsg").val());
                        } else if (result.Reason === "ToLarge") {
                            self.fileUploadErrorMessage($("#ToLargeMsg").val());
                        } else if (result.Reason === "FileMissing") {
                            self.fileUploadErrorMessage($("#FileMissingMsg").val());
                        } else if (result.Reason === "MissingCulture") {
                            self.fileUploadErrorMessage($("#MissingCultureMsg").val());
                        }

                    }
                }).fail(function (result) {
                    self.fileUploadHasError(true);
                    self.fileUploadErrorMessage($("#ErrorUploadingFileLbl").val());
                }).always(function () {
                    $("#waitModal").modal("hide");
                    event.target.files = null;

                    $("#documentPicker").remove();
                    $("#fileParent").prepend('<input type="file" id="documentPicker" name="file" />');
                    self.selectedCulture("");
                });
            };
        });

    } else if (typeof window.FormData === "undefined") {
        self.formDataSupported(false);
        self.fileUploadErrorMessage($("#FileNotSupportedLbl").val());
        self.fileUploadHasError(true);
    }


    self.workPostedDate.subscribe(function (data) {

        if (moment(data).isValid()) {
            self.postedDate(moment(data).format("YYYY-MM-DD HH:mm"));
        } else {
            self.postedDate("");
        }
    });


    //generates the list of cultures
    self.buildDocCultures = ko.computed(function () {
        self.docCultures([]);

        var valid = jQuery.grep(self.letterTranslations(), function (e) {
            return e.translationObjectValid();
        });

        if (valid !== undefined && valid !== null && valid.length !== 0) {
            $.each(valid, function (index, letterKo) {
                if (letterKo.translationObjectValid()) {
                    self.docCultures.push(new GenericDisplayOption(letterKo.culture(), letterKo.culture()));
                }
            });
        }
    });

    //title for the question (mostly for developer use)
    self.letterName = ko.computed(function () {
        if ($.trim(self.letterTranslations()[0].letterNameTranslation()) === "") {
            self.developerLetterName($("#PlaceHolderLetterNameLbl").val());
        } else {
            self.developerLetterName(self.letterTranslations()[0].letterNameTranslation());
        }
    });

    self.workPostedDateValid = ko.computed(function () {
        if (self.workPostedDate() === "") {
            self.postedDateClassName(GetFormClass(false));
            self.validPostedDateClassName(GetFormIconClass(false));
            return false;
        }

        if (self.postedDate() === "") {
            self.postedDateClassName(GetFormClass(false));
            self.validPostedDateClassName(GetFormIconClass(false));
            return false;
        }

        self.postedDateClassName(GetFormClass(true));
        self.validPostedDateClassName(GetFormIconClass(true));
        return true;
    });


    self.letterDetailsValid = ko.computed(function () {
        if (!self.workPostedDateValid()) {
            self.validLetterDetailsClassName(GetFormIconClass(false));
            return false;
        }

        self.validLetterDetailsClassName(GetFormIconClass(true));
        return true;
    });

    //are all of the app name translations valid?
    self.letterTranslationsValid = ko.computed(function () {
        var translationsNotValid = jQuery.grep(self.letterTranslations(), function (e) {
            if (!e.translationObjectValid()) {
                return true;
            }
            return false;
        });

        if (translationsNotValid.length > 0) {
            self.validLetterDetailTranslationClassName(GetFormIconClass(false));
            return false;
        }

        self.validLetterDetailTranslationClassName(GetFormIconClass(true));
        return true;
    });

    self.attachedDocumentsValid = ko.computed(function () {

        if (!self.attachedDocuments().length > 0) {
            self.validAttachedDocumentsClassName(GetFormIconClass(false));
            return false;
        }

        self.validAttachedDocumentsClassName(GetFormIconClass(true));
        return true;
    });

    //is the app valid and able to save
    self.letterValid = ko.computed(function () {

        if (!self.letterTranslationsValid()) {
            return false;
        }

        if (!self.attachedDocumentsValid()) {
            return false;
        }

        if (!self.letterDetailsValid()) {
            return false;
        }

        return true;

    });

    self.isLoaded(true);

}

//application edit list
function BuildNewLetterEditList(appModel) {
    var self = this;

    self.letterId = appModel.LetterId;
    self.lastModifyUserId = appModel.LastModifyUserId;
    self.lastModifyTs = appModel.LastModifyTs;
    self.letterNameTranslation = appModel.LetterNameTranslation;
}


//build out the attached document object
function AttachedDocumentObject(fileName, rootKo, docModel, isNew) {
    var self = this;
    self.letterId = rootKo.letterId;
    self.base64Encoded = docModel.Base64Encoded;
    self.fileName = fileName === null ? docModel.FileName : fileName;
    self.contentType = docModel.ContentType;
    self.culture = docModel.Culture !== null && docModel.Culture !== undefined ? docModel.Culture : rootKo.selectedCulture();
    self.guid = docModel.Guid;

    if (rootKo.letterHistoryId() !== "") {
        self.href = $("#downloadUrl").val().replace("cultureTest", self.culture).replace("idTest", rootKo.letterHistoryId()).replace("versionTest", "archive");
    } else {
        self.href = $("#downloadUrl").val().replace("cultureTest", self.culture).replace("idTest", self.letterId).replace("versionTest", "release");
    }



    self.isNew = isNew;
}


//builds the translation section for each translation area
function BuildTranslation(isFirst, isManual, rootKo, translationModel) {
    var self = this;

    self.isFirst = isFirst;
    self.cultures = rootKo.globalCultures;
    self.culture = ko.observable(isManual && isFirst ? "en-us" : isManual ? "" : translationModel.Culture);
    self.isManual = ko.observable(isManual && !isFirst);
    self.letterNameTranslation = ko.observable(isManual ? "" : translationModel.LetterNameTranslation);
    self.cultureIsDuplicate = ko.observable(false);

    //statics
    self.cultureLocked = self.culture().toLowerCase() === "en-us";

    //css class names
    self.cultureClassName = ko.observable("");
    self.letterNameTranslationClassName = ko.observable("");
    self.validLetterDetailTranslationClassName = ko.observable("");

    //make an input readonly
    self.inputReadonlyState = function () {
        if (!self.cultureLocked) {
            return undefined;
        } else {
            return "readonly";
        }
    }

    //this will handle the error checking for duplicate cultures
    self.culture.subscribe(function (data) {

        $.each(rootKo.letterTranslations(), function (index, letterKo) {
            letterKo.cultureIsDuplicate(false);
        });

        var badTranslations = jQuery.grep(rootKo.letterTranslations(), function (e) {
            return data === e.culture();
        });

        if (badTranslations !== undefined && badTranslations !== null && badTranslations.length > 1) {
            $.each(badTranslations, function (index, letterKo) {
                letterKo.cultureIsDuplicate(true);
            });
        }
    });

    //is the culture entered valid?
    self.cultureValid = ko.computed(function () {
        if ($.trim(self.culture()) === "") {
            self.cultureClassName(GetFormClass(false));
            return false;
        }

        //if entered, validate, must match xx-xx lower case only
        var m = self.culture().match(/^[a-z]{2}-[a-z]{2}$/);
        if (m === null) {
            self.cultureClassName(GetFormClass(false));
            return false;
        }

        if (self.cultureIsDuplicate()) {
            self.cultureClassName(GetFormClass(false));
            return false;
        }

        self.cultureClassName(GetFormClass(true));
        return true;

    });

    //is the entered translation valid?
    self.letterNameTranslationValid = ko.computed(function () {
        if ($.trim(self.letterNameTranslation()) === "") {
            self.letterNameTranslationClassName(GetFormClass(false));
            return false;
        }

        self.letterNameTranslationClassName(GetFormClass(true));
        return true;

    });

    //is the entire translation object valid
    self.translationObjectValid = ko.computed(function () {
        if (!self.cultureValid()) {
            self.validLetterDetailTranslationClassName(GetFormIconClass(false));
            return false;
        }

        if (!self.letterNameTranslationValid()) {
            self.validLetterDetailTranslationClassName(GetFormIconClass(false));
            return false;
        }

        self.validLetterDetailTranslationClassName(GetFormIconClass(true));
        return true;
    });
}


//generate the object that holds the entire history model
function BuildHistoryObject(historyModel) {
    var self = this;
    self.viewModel = historyModel.LetterModel;
    self.letterId = historyModel.LetterId;
    self.letterHistoryId = historyModel.LetterHistoryId;
    self.lastModifyUserId = $.trim(historyModel.LastModifyUserId);
    self.lastModifyTs = historyModel.LastModifyTs;
}

//builds a generic value/display drop down option
function GenericDisplayOption(display, value) {
    var self = this;

    self.display = display;
    self.value = value;
}

//function that handles the form field validation class names
function GetFormClass(isValid) {
    if (isValid) {
        return "form-control";
    }

    return "form-control is-invalid";
}

//function that handles the form field validation icon class names
function GetFormIconClass(isValid) {
    if (isValid) {
        return "fa fa-check text-success";
    }

    return "fa fa-exclamation-triangle text-danger";
}