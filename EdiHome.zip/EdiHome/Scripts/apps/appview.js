﻿var KoModel = function(viewModel) {
    var self = this;

    self.applications = ko.observableArray([]);
    self.errorMessage = ko.observable("");
    self.isLoaded = ko.observable(false);
    self.isAdmin = viewModel.IsAdmin;
    self.isNonAdminWalmart = viewModel.IsNonAdminWalmart;
    self.isSupplier = viewModel.IsSupplier;
    self.fileCulture = viewModel.fileCulture;
    

    $.each(viewModel.AllApps, function (index, appModel) {
        self.applications.push(new BuildApplication(appModel));
    });

    self.isLoaded(true);
}


function BuildApplication(appModel) {
    var self = this;

    self.appId = appModel.AppId;
    self.appDescTranslation = appModel.AppDescTranslation;
    self.appNameTranslation = appModel.AppNameTranslation;
    self.appPath = appModel.AppPath;
    self.showExternally = appModel.ShowExternally;
    self.fileCulture = appModel.FileCulture;
    self.lastModifyTs = appModel.LastModifyTs;

    self.href = $("#downloadUrl").val().replace("cultureTest", self.fileCulture).replace("appIdTest", self.appId).replace("versionTest", "release");

    self.downloadTooltip = $("#DownloadDocumentationLbl").val();
}
