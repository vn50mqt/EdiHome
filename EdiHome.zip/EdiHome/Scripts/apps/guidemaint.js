﻿var KoModel = function (viewModel) {
    var self = this;

    self.businessTypes = ko.observableArray([]);
    self.countries = ko.observableArray([]);
    self.isEdit = viewModel.IsEdit;
    self.isLoaded = ko.observable(false);
    self.allGuides = ko.observableArray([]);
    self.documentFlows = ko.observableArray([]);
    self.guideId = viewModel.GuideId;
    self.guideHistoryId = ko.observable("");
    self.attachedDocuments = ko.observableArray([]);
    self.displayLastModifiedMessage = ko.observable(viewModel.IsEdit);
    self.errorMessage = ko.observable("");
    self.fileUploadErrorMessage = ko.observable("");
    self.fileUploadHasError = ko.observable(false);
    self.formDataSupported = ko.observable(true);
    self.globalCultures = [];
    self.hasHistory = ko.observable(viewModel.GuideHistory.length > 0);
    self.historyList = ko.observableArray([]);
    self.isLoadingData = ko.observable(false);
    self.isResponseGuidesEnabled = ko.observable(true);
    self.lastModifyUserId = ko.observable(viewModel.LastModifyUserId);
    self.lastModifyTs = ko.observable(new Date(Date.parse(viewModel.LastModifyTs)));
    self.responseGuides = ko.observableArray([]);
    self.selectedBusinessType = ko.observable(viewModel.SelectedBusinessType);
    self.selectedCulture = ko.observable("");
    self.selectedCountries = ko.observableArray([]);
    self.selectedDocument = ko.observable("");
    self.selectedDisplayExternally = ko.observable(viewModel.SelectedDisplayExternally);
    self.selectedDocumentFlow = ko.observable(viewModel.SelectedDocumentFlow);
    self.selectedIsResponseGuide = ko.observable(viewModel.SelectedIsResponseGuide);
    self.selectedResponseGuide = ko.observable(viewModel.SelectedResponseGuide);
    self.selectedStandard = ko.observable(viewModel.SelectedStandard);
    self.selectedUsage = ko.observable("");
    self.selectedVersion = ko.observable("");
    self.businessTypes = ko.observableArray([]);
    self.documents = ko.observableArray([]);
    self.standards = ko.observableArray([]);
    self.usages = ko.observableArray([]);
    self.versions = ko.observableArray([]);
    self.yesNoOptions = ko.observableArray([]);

    self.workMajorUpdateDate = ko.observable(viewModel.WorkMajorUpdateDate);
    self.majorUpdateDate = ko.observable(viewModel.WorkMajorUpdateDate !== null && viewModel.WorkMajorUpdateDate !== "" ? moment(self.workMajorUpdateDate()).format("YYYY-MM-DD") : "");

    //css observables
    self.validBusinessTypesClassName = ko.observable("");
    self.validCountriesClassName = ko.observable("");
    self.validDocumentsClassName = ko.observable("");
    self.validDocumentFlowClassName = ko.observable("");
    self.validMajorUpdateDateClassName = ko.observable("");
    self.validStandardsClassName = ko.observable("");
    self.validUsagesClassName = ko.observable("");
    self.validVersionsClassName = ko.observable("");
    self.validGuideDetailTranslationClassName = ko.observable("");
    self.validGuideDetailsClassName = ko.observable("");
    self.validAttachedDocumentsClassName = ko.observable("");

    self.majorUpdateDateClassName = ko.observable("");

    //tooltips
    self.documentTooltip = ko.observable($("#GuideDocumentTooltipMsg").val());
    self.showExternalTooltip = ko.observable($("#ShowExternalTooltipMsg").val());
    self.countriesTooltip = ko.observable($("#CountriesTooltipMsg").val());
    self.businessTypeTooltip = ko.observable($("#BusinessTypeTooltipMsg").val());
    self.standardTooltip = ko.observable($("#StandardTooltipMsg").val());
    self.versionTooltip = ko.observable($("#VersionTooltipMSg").val());
    self.documentSelectionTooltip = ko.observable($("#DocumentSelectionTooltipMsg").val());
    self.usageTooltip = ko.observable($("#UsageTooltipMsg").val());
    self.isResponseGuideTooltip = ko.observable($("#IsResponseGuideTooltipMsg").val());
    self.responseGuidesTooltip = ko.observable($("#ResponseGuidesTooltipMsg").val());
    self.majorUpdateDateTooltip = ko.observable($("#MajorUpdateDateTooltipMsg").val());
    self.documentFlowTooltip = ko.observable($("#DocumentFlowTooltipMsg").val());

    //yes/no dropdown
    self.yesNoOptions.push(new GenericDisplayOption($("#NoLbl").val(), false));
    self.yesNoOptions.push(new GenericDisplayOption($("#YesLbl").val(), true));

    self.documentFlows.push(new GenericDisplayOption($("#ChooseDocumentFlowLbl").val(), ""));
    self.documentFlows.push(new GenericDisplayOption($("#ChooseDocumentFlowBiDirectionLbl").val(), "BIDIRECTION"));
    self.documentFlows.push(new GenericDisplayOption($("#ChooseDocumentFlowToWalmartLbl").val(), "TOWALMART"));
    self.documentFlows.push(new GenericDisplayOption($("#ChooseDocumentFlowFromWalmartLbl").val(), "FROMWALMART"));


    if (viewModel.AllGuides.length > 0) {
        $.each(viewModel.AllGuides, function (index, guideModel) {
            self.allGuides.push(new BuildNewGuideEditList(guideModel));
        });
    }

    $.each(viewModel.SelectedCountries, function (index, country) {
        self.selectedCountries.push(country);
    });


    $.each(viewModel.Countries, function (index, countryModel) {
        self.countries.push(new GenericDisplayOption(countryModel.CountryDescription, countryModel.CountryCode));
    });

    self.businessTypes.push(new GenericDisplayOption($("#ChooseBusinessTypeLbl").val(), ""));
    $.each(viewModel.BusinessTypes, function (index, busTypeModel) {
        self.businessTypes.push(new GenericDisplayOption(busTypeModel.BusinessTypeDesc, busTypeModel.BusinessTypeRef));
    });

    self.standards.push(new GenericDisplayOption($("#ChooseStandardLbl").val(), ""));
    $.each(viewModel.Standards, function (index, standard) {
        self.standards.push(new GenericDisplayOption(standard, standard));
    });

    self.responseGuides.push(new GenericDisplayOption($("#ChooseResponseGuideLbl").val(), 0));
    $.each(viewModel.ResponseGuides, function (index, guide) {
        self.responseGuides.push(new GenericDisplayOption(guide.ResponseGuideDesc, guide.ResponseGuideId));
    });

    //only preload these if is edit is true
    if (self.isEdit) {
        self.versions.push(new GenericDisplayOption($("#ChooseVersionLbl").val(), ""));
        $.each(viewModel.Versions, function (index, versionModel) {
            self.versions.push(new GenericDisplayOption(versionModel, versionModel));
        });

        self.documents.push(new GenericDisplayOption($("#ChooseDocumentLbl").val(), ""));
        $.each(viewModel.Documents, function (index, documentModel) {
            self.documents.push(new GenericDisplayOption(documentModel, documentModel));
        });

        self.usages.push(new GenericDisplayOption($("#ChooseUsageLbl").val(), ""));
        $.each(viewModel.Usages, function (index, usageModel) {
            self.usages.push(new GenericDisplayOption(usageModel.UsageDesc, usageModel.UsageRef));
        });

        self.selectedDocument(viewModel.SelectedDocument);
        self.selectedVersion(viewModel.SelectedVersion);
        self.selectedUsage(viewModel.SelectedUsage);

        if (self.selectedIsResponseGuide()) {
            self.isResponseGuidesEnabled(false);
        }
    }


    //load the history
    $.each(viewModel.GuideHistory, function (index, guideModel) {
        self.historyList.push(new BuildHistoryObject(guideModel));
    });

    //load any attached document info
    $.each(viewModel.AttachedDocuments, function (index, docModel) {
        self.attachedDocuments.push(new AttachedDocumentObject(null, self, docModel, false));
    });

    ////load global cultures
    self.globalCultures.push(new GenericDisplayOption("", ""));
    $.each(viewModel.GlobalCultures, function (index, cultureModel) {
        self.globalCultures.push(new GenericDisplayOption(cultureModel, cultureModel));
    });
    self.selectedCulture("en-us");

    //save the app settings
    self.saveGuide = function () {
        $.ajax({
            type: "Post",
            url: $("#savePath").val(),
            data: {
                guideDetails: ko.toJSON(self),
                guideId: self.guideId,
                historyId: self.guideHistoryId()
            },
            datatype: "json"
        })
            .done(function (result) {
                if (!result.HasFailure) {
                    self.lastModifyUserId(result.LastModifyUserId);
                    //have to parse it like this due to how it's passed through the JsonResult
                    self.lastModifyTs(new Date(result.LastModifyTs.match(/\d+/)[0] * 1));
                    if (self.guideId !== 0) {
                        self.refreshHistory();
                    } else {
                        $("#successModal").modal("toggle");
                    }
                } else {
                    self.errorMessage($("#SaveGuideDetailsErrorMsg").val());
                    $("#errorModal").modal("show");
                }
            })
            .fail(function (result) {
                self.errorMessage($("#SaveGuideDetailsErrorMsg").val());
                $("#errorModal").modal("show");
            });
    }

    //load a specific instance of the application configurations
    self.loadHistoricalGuideEntry = function (data) {
        //reset lists
        self.attachedDocuments([]);

        self.lastModifyUserId(data.lastModifyUserId);
        self.lastModifyTs(new Date(Date.parse(data.lastModifyTs)));
        self.guideHistoryId(data.guideHistoryId);

        //load any attached document info
        $.each(data.viewModel.AttachedDocuments, function (index, docModel) {
            self.attachedDocuments.push(new AttachedDocumentObject(null, self, docModel, false));
        });

        $("#historyModal").modal("toggle");
    };

    //this is the easiest way to refresh the history, but reloading the current maintenance screen
    self.refreshHistory = function () {
        window.location = $("#refreshUrl").val();
    }

    //open the modal
    self.toggleHistoryModal = function () {
        $("#historyModal").modal("toggle");
    }

    //redirect to new add page
    self.addNewGuide = function () {
        window.location = $("#addNewGuideUrl").val();
    }

    //delete the document attached
    self.deleteAttachedDocument = function (data) {
        self.attachedDocuments.remove(data);
    }

    self.loadGuideForEdit = function (data) {
        var editUrl = $("#editGuideUrl").val().replace("idTest", data.guideId);
        window.location = editUrl;
    }

    self.loadResponseGuideForEdit = function (data) {
        var editUrl = $("#editGuideUrl").val().replace("idTest", data.responseGuideId);
        window.location = editUrl;
    }

    self.deleteGuideFromDb = function (data) {
        $.ajax({
            type: "Post",
            url: $("#deleteGuideUrl").val(),
            data: {
                guideId: data.guideId
            },
            datatype: "json"
        })
            .done(function (result) {
                if (result) {
                    window.location = $("#addNewGuideUrl").val();
                } else {
                    self.errorMessage($("#DeleteGuideDetailsErrorMsg").val());
                    $("#errorModal").modal("show");
                }
            })
            .fail(function (result) {
                self.errorMessage($("#DeleteGuideDetailsErrorMsg").val());
                $("#errorModal").modal("show");
            });
    }

    //will handle the file upload converter from binary to base64 string so it can be embedded in the xml or json and verify the type and size
    if (typeof window.FormData !== "undefined") {

        self.fileUploadErrorMessage("");

        $("#fileParent").on("change", "#documentPicker", function (event) {
            var file = event.target.files[0];
            if (file) {

                $("#waitModal").modal("show");
                //set the form data
                var formData = new FormData();
                formData.append("guideDocumentation", file);
                formData.append("culture", self.selectedCulture());

                $.ajax({
                    url: $("#fileHandler").val(),
                    type: "POST",
                    data: formData,
                    cache: false,
                    contentType: false,
                    processData: false
                }).done(function (result) {
                    if (result.Success) {
                        self.fileUploadHasError(false);
                        self.fileUploadErrorMessage("");

                        var isCultureAttached = jQuery.grep(self.attachedDocuments(), function (e) {
                            return e.culture === self.selectedCulture();
                        });

                        if (isCultureAttached !== undefined && isCultureAttached !== null && isCultureAttached.length > 0) {
                            self.attachedDocuments.remove(isCultureAttached[0]);
                        }

                        self.attachedDocuments.push(new AttachedDocumentObject(file.name, self, result, true));

                    } else {
                        self.fileUploadHasError(true);

                        if (result.Reason === "WrongType") {
                            self.fileUploadErrorMessage($("#WrongTypeMsg").val());
                        } else if (result.Reason === "ToLarge") {
                            self.fileUploadErrorMessage($("#ToLargeMsg").val());
                        } else if (result.Reason === "FileMissing") {
                            self.fileUploadErrorMessage($("#FileMissingMsg").val());
                        } else if (result.Reason === "MissingCulture") {
                            self.fileUploadErrorMessage($("#MissingCultureMsg").val());
                        }

                    }
                }).fail(function (result) {
                    self.fileUploadHasError(true);
                    self.fileUploadErrorMessage($("#ErrorUploadingFileLbl").val());
                }).always(function () {
                    $("#waitModal").modal("hide");
                    event.target.files = null;

                    $("#documentPicker").remove();
                    $("#fileParent").prepend('<input type="file" id="documentPicker" name="file" />');
                    self.selectedCulture("");
                });
            };
        });

    } else if (typeof window.FormData === "undefined") {
        self.formDataSupported(false);
        self.fileUploadErrorMessage($("#FileNotSupportedLbl").val());
        self.fileUploadHasError(true);
    }

    self.selectedIsResponseGuide.subscribe(function (data) {
        if (data) {
            self.selectedResponseGuide(0);
            self.isResponseGuidesEnabled(false);
        } else {
            self.selectedResponseGuide(0);
            self.isResponseGuidesEnabled(true);
        }
    });


    self.selectedCountries.subscribe(function (data) {
        var globalCheck = jQuery.grep(self.selectedCountries(), function (country) {
            return country === "ZZ";
        });

        var nonGlobalCheck = jQuery.grep(self.selectedCountries(), function (country) {
            return country !== "ZZ";
        });

        if (typeof globalCheck !== "undefined" && globalCheck !== null && globalCheck.length !== 0) {
            $.each(nonGlobalCheck, function (index, country) {
                self.selectedCountries.remove(country);
            });
            
        }
    });

    self.selectedStandard.subscribe(function (data) {
        self.isLoadingData(true);

        //reset all drop downs below this level and re-query
        self.resetFieldsBelowLevel("standard");
        if (typeof data !== "undefined" && data !== "" && data !== null) {
            self.getVersions(data);
        } else {
            self.isLoadingData(false);
        }
    });

    self.selectedVersion.subscribe(function (data) {
        self.isLoadingData(true);

        //reset all drop downs below this level and re-query
        self.resetFieldsBelowLevel("version");
        if (typeof data !== "undefined" && data !== "" && data !== null) {
            self.getDocuments(data);
        } else {
            self.isLoadingData(false);
        }
    });

    self.selectedDocument.subscribe(function (data) {
        self.isLoadingData(true);

        //reset all drop downs below this level and re-query
        self.resetFieldsBelowLevel("document");
        if (typeof data !== "undefined" && data !== "" && data !== null) {
            self.getUsages(data);
        } else {
            self.isLoadingData(false);
        }
    });

    self.workMajorUpdateDate.subscribe(function (data) {
        if (moment(data).isValid()) {
            self.majorUpdateDate(moment(data).format("YYYY-MM-DD"));
        } else {
            self.majorUpdateDate("");
        }
    });

    self.getVersions = function(standard) {
        $.ajax({
                type: "Post",
                url: $("#loadVersionsUrl").val(),
                data: {
                    standard: standard
                },
                datatype: "json"
            })
            .done(function (result) {
                if (result) {
                    self.versions.push(new GenericDisplayOption($("#ChooseVersionLbl").val(), ""));
                    $.each(result, function (index, version) {
                        self.versions.push(new GenericDisplayOption(version,version));
                    });
                } else {
                    self.errorMessage();
                    $("#errorModal").modal("show");
                }

            })
            .fail(function (result) {
                self.errorMessage($("#ChooseVersionErrorMsg").val());
                $("#errorModal").modal("show");
            })
            .always(function (result) {
                self.isLoadingData(false);
            });
    }

    self.getDocuments = function (version) {
        $.ajax({
                type: "Post",
                url: $("#loadDocumentsUrl").val(),
                data: {
                    standard: self.selectedStandard(),
                    version: version
                },
                datatype: "json"
            })
            .done(function (result) {
                if (result) {
                    self.documents.push(new GenericDisplayOption($("#ChooseDocumentLbl").val(), ""));
                    $.each(result, function (index, document) {
                        self.documents.push(new GenericDisplayOption(document, document));
                    });
                } else {
                    self.errorMessage($("#ChooseDocumentErrorMsg").val());
                    $("#errorModal").modal("show");
                }

            })
            .fail(function (result) {
                self.errorMessage($("#ChooseDocumentErrorMsg").val());
                $("#errorModal").modal("show");
            })
            .always(function (result) {
                self.isLoadingData(false);
            });
    }

    self.getUsages = function (document) {
        $.ajax({
                type: "Post",
                url: $("#loadUsagesUrl").val(),
                data: {
                    standard: self.selectedStandard(),
                    version: self.selectedVersion(),
                    document: document 
                },
                datatype: "json"
            })
            .done(function (result) {
                if (result) {
                    self.usages.push(new GenericDisplayOption($("#ChooseUsageLbl").val(), ""));
                    $.each(result, function (index, usageModel) {
                        self.usages.push(new GenericDisplayOption(usageModel.UsageDesc, usageModel.UsageRef));
                    });
                } else {
                    self.errorMessage($("#ChooseUsageErrorMsg").val());
                    $("#errorModal").modal("show");
                }

            })
            .fail(function (result) {
                self.errorMessage($("#ChooseUsageErrorMsg").val());
                $("#errorModal").modal("show");
            })
            .always(function (result) {
                self.isLoadingData(false);
            });
    }

    self.resetFieldsBelowLevel = function(resetLevel) {
        if (resetLevel === "standard") {
            self.versions([]);
            self.documents([]);
            self.usages([]);

            self.selectedVersion("");
            self.selectedDocument("");
            self.selectedUsage("");

        } else if (resetLevel === "version") {
            self.documents([]);
            self.usages([]);

            self.selectedDocument("");
            self.selectedUsage("");
        } else if (resetLevel === "document") {
            self.usages([]);

            self.selectedUsage("");
        }
    }

    self.versionsEnabled = ko.computed(function () {
        if (self.isLoadingData()) {
            return false;
        }

        if (typeof self.selectedStandard() === "undefined" || self.selectedStandard() === "") {
            return false;
        }

        return true;
    });

    self.documentsEnabled = ko.computed(function () {
        if (self.isLoadingData()) {
            return false;
        }

        if (typeof self.selectedVersion() === "undefined" || self.selectedVersion() === "") {
            return false;
        }

        return true;
    });

    self.usagesEnabled = ko.computed(function () {
        if (self.isLoadingData()) {
            return false;
        }

        if (typeof self.selectedDocument() === "undefined" || self.selectedDocument() === "") {
            return false;
        }

        return true;
    });

    self.countriesValid = ko.computed(function () {
        if (!self.selectedCountries().length > 0) {
            self.validCountriesClassName(GetFormIconClass(false));
            return false;
        }

        self.validCountriesClassName(GetFormIconClass(true));
        return true;
    });

    self.businessTypesValid = ko.computed(function () {
        if (typeof self.selectedBusinessType() === "undefined" || self.selectedBusinessType() === "") {
            self.validBusinessTypesClassName(GetFormIconClass(false));
            return false;
        }

        self.validBusinessTypesClassName(GetFormIconClass(true));
        return true;
    });

    self.standardsValid = ko.computed(function () {
        if (typeof self.selectedStandard() === "undefined" || self.selectedStandard() === "") {
            self.validStandardsClassName(GetFormIconClass(false));
            return false;
        }

        self.validStandardsClassName(GetFormIconClass(true));
        return true;
    });

    self.versionsValid = ko.computed(function () {
        if (typeof self.selectedVersion() === "undefined" || self.selectedVersion() === "") {
            self.validVersionsClassName(GetFormIconClass(false));
            return false;
        }

        self.validVersionsClassName(GetFormIconClass(true));
        return true;
    });

    self.documentsValid = ko.computed(function () {
        if (typeof self.selectedDocument() === "undefined" || self.selectedDocument() === "") {
            self.validDocumentsClassName(GetFormIconClass(false));
            return false;
        }

        self.validDocumentsClassName(GetFormIconClass(true));
        return true;
    });

    self.usagesValid = ko.computed(function () {
        if (typeof self.selectedUsage() === "undefined" || self.selectedUsage() === "") {
            self.validUsagesClassName(GetFormIconClass(false));
            return false;
        }

        self.validUsagesClassName(GetFormIconClass(true));
        return true;
    });

    self.majorUpdateDateValid = ko.computed(function () {
        if (self.majorUpdateDate() === "" || moment(self.workMajorUpdateDate()).isValid()) {
            
            return true;
        } else {
            return false;
        }
    });

    self.selectedDocumentFlowValid = ko.computed(function () {
        if (self.selectedDocumentFlow() === "") {
            self.validDocumentFlowClassName(GetFormIconClass(false));
            return false;
        }

        self.validDocumentFlowClassName(GetFormIconClass(true));
        return true;
    });

    //are the guide details completed
    self.guideDetailsValid = ko.computed(function () {
        if (!self.countriesValid()) {
            self.validGuideDetailsClassName(GetFormIconClass(false));
            return false;
        }

        if (!self.businessTypesValid()) {
            self.validGuideDetailsClassName(GetFormIconClass(false));
            return false;
        }

        if (!self.standardsValid()) {
            self.validGuideDetailsClassName(GetFormIconClass(false));
            return false;
        }

        if (!self.versionsValid()) {
            self.validGuideDetailsClassName(GetFormIconClass(false));
            return false;
        }

        if (!self.documentsValid()) {
            self.validGuideDetailsClassName(GetFormIconClass(false));
            return false;
        }

        if (!self.usagesValid()) {
            self.validGuideDetailsClassName(GetFormIconClass(false));
            return false;
        }

        if (!self.selectedDocumentFlowValid()) {
            self.validGuideDetailsClassName(GetFormIconClass(false));
            return false;
        }

        self.validGuideDetailsClassName(GetFormIconClass(true));
        return true;
    });


    //are the attached documents meeting requirements?
    self.attachedDocumentsValid = ko.computed(function () {

        if (!self.attachedDocuments().length > 0) {
            self.validAttachedDocumentsClassName(GetFormIconClass(false));
            return false;
        }

        var cultureExists = jQuery.grep(self.attachedDocuments(), function (e) {
            return e.culture === "en-us";
        });

        //if the culture doesn't exist, then and only then remove the document (this will prevent accidental deletion when adding new lines where the culture matched and removing it before changing culture)
        if (cultureExists === undefined || cultureExists === null || cultureExists.length === 0) {
            self.validAttachedDocumentsClassName(GetFormIconClass(false));
            return false;
        }

        self.validAttachedDocumentsClassName(GetFormIconClass(true));
        return true;
    });

    //is the app valid and able to save
    self.guideValid = ko.computed(function () {

        if (!self.attachedDocumentsValid()) {
            return false;
        }

        if (!self.guideDetailsValid()) {
            return false;
        }

        return true;

    });

    self.isLoaded(true);

}

//application edit list
function BuildNewGuideEditList(guideModel) {
    var self = this;

    self.guideId = guideModel.GuideId;
    self.responseGuideId = guideModel.SelectedResponseGuide;
    self.lastModifyUserId = guideModel.LastModifyUserId;
    self.lastModifyTs = guideModel.LastModifyTs;
    self.guideName = guideModel.GuideName;
    self.isResponseGuide = guideModel.SelectedIsResponseGuide;
    self.countries = [];

    $.each(guideModel.SelectedCountries, function (index, countryModel) {
        self.countries.push(countryModel);
    });

}


//build out the attached document object
function AttachedDocumentObject(fileName, rootKo, docModel, isNew) {
    var self = this;
    self.guideId = rootKo.guideId;
    self.base64Encoded = docModel.Base64Encoded;
    self.fileName = fileName === null ? docModel.FileName : fileName;
    self.contentType = docModel.ContentType;
    self.culture = docModel.Culture !== null && docModel.Culture !== undefined ? docModel.Culture : rootKo.selectedCulture();
    self.guid = docModel.Guid;

    if (rootKo.guideHistoryId() !== "") {
        self.href = $("#downloadUrl").val().replace("cultureTest", self.culture).replace("idTest", rootKo.guideHistoryId()).replace("versionTest", "archive");
    } else {
        self.href = $("#downloadUrl").val().replace("cultureTest", self.culture).replace("idTest", self.guideId).replace("versionTest", "release");
    }

    self.isNew = isNew;
}


//generate the object that holds the entire history model
function BuildHistoryObject(historyModel) {
    var self = this;
    self.viewModel = historyModel.GuideModel;
    self.guideId = historyModel.GuideId;
    self.guideHistoryId = historyModel.GuideHistoryId;
    self.lastModifyUserId = $.trim(historyModel.LastModifyUserId);
    self.lastModifyTs = historyModel.LastModifyTs;
}

//builds a generic value/display drop down option
function GenericDisplayOption(display, value) {
    var self = this;

    self.display = display;
    self.value = value;
}

//function that handles the form field validation class names
function GetFormClass(isValid) {
    if (isValid) {
        return "form-control";
    }

    return "form-control is-invalid";
}

//function that handles the form field validation icon class names
function GetFormIconClass(isValid) {
    if (isValid) {
        return "fa fa-check text-success";
    }

    return "fa fa-exclamation-triangle text-danger";
}