﻿var KoModel = function (viewModel) {
    var self = this;

    self.isLoaded = ko.observable(false);
    self.isFilterLoading = ko.observable(false);
    self.isFilterSelectionLoaded = ko.observable(false);
    self.spinnerVisible = ko.observable(false);

    self.countries = ko.observableArray([]);
    self.businessTypes = ko.observableArray([]);
    self.documents = ko.observableArray([]);
    self.errorMessage = ko.observable("");
    self.guides = ko.observableArray([]);
    self.standards = ko.observableArray([]);
    self.usages = ko.observableArray([]);
    self.versions = ko.observableArray([]);

    self.versionsEnabled = ko.observable(false);
    self.documentsEnabled = ko.observable(false);
    self.usagesEnabled = ko.observable(false);

    self.selectedBusinessType = ko.observable("");
    self.selectedBusinessTypeDisplay = ko.observable("");
    self.selectedCulture = viewModel.FileCulture;
    self.selectedCountry = ko.observable(viewModel.SearchCriteria.SelectedCountry);
    self.selectedCountryDisplay = ko.observable(viewModel.SearchCriteria.SelectedCountry);
    self.selectedStandard = ko.observable("");

    self.filterStandardBadgeClass = ko.observable(GetBadgeFilterClass(true));
    self.filterBusinessTypeBadgeClass = ko.observable(GetBadgeFilterClass(true));
    self.filterCountryBadgeClass = ko.observable(GetBadgeFilterClass(true));

    self.countries.push(new GenericDisplayOption($("#ChooseCountryLbl").val(), ""));
    $.each(viewModel.Countries, function (index, countryModel) {
        self.countries.push(new GenericDisplayOption(countryModel.CountryDescription, countryModel.CountryCode));
    });

    self.businessTypes.push(new GenericDisplayOption($("#ChooseBusinessTypeLbl").val(), ""));
    $.each(viewModel.BusinessTypes, function (index, busTypeModel) {
        self.businessTypes.push(new GenericDisplayOption(busTypeModel.BusinessTypeDesc, busTypeModel.BusinessTypeRef));
    });

    self.standards.push(new GenericDisplayOption($("#ChooseStandardLbl").val(), ""));
    $.each(viewModel.Standards, function (index, standardModel) {
        self.standards.push(new GenericDisplayOption(standardModel, standardModel));
    });


    //pretty selected country text
    self.selectedCountry.subscribe(function (data) {
        if (data === "ZZ") {
            self.selectedCountryDisplay($("#globalTrans").val());
        } else {
            self.selectedCountryDisplay(data);
        }
    });

    //pretty business type text
    self.selectedBusinessType.subscribe(function (data) {
        if (typeof data === "undefined" || data === null || data === "") {
            self.selectedBusinessTypeDisplay("");
        } else {
            var descText = jQuery.grep(self.businessTypes(), function (e) {
                return e.value === data;
            })[0];

            self.selectedBusinessTypeDisplay(descText.display);
        }
    });

    self.removeFilter = function(level, data) {
        
        if (level === "country") {
            self.selectedCountry("");
        }

        if (level === "standard") {
            self.selectedStandard("");
        }

        if (level === "busType") {
            self.selectedBusinessType("");
        } 

        self.saveFilter(false);
    }

    self.setRemoveCss = function(level, data) {
        if (level === "country") {
            self.filterCountryBadgeClass(GetBadgeFilterClass(false));
        }

        if (level === "standard") {
            self.filterStandardBadgeClass(GetBadgeFilterClass(false));
        }

        if (level === "busType") {
            self.filterBusinessTypeBadgeClass(GetBadgeFilterClass(false));
        }
    }


    self.setDefaultCss = function (level, data) {

        if (level === "country") {
            self.filterCountryBadgeClass(GetBadgeFilterClass(true));
        }

        if (level === "standard") {
            self.filterStandardBadgeClass(GetBadgeFilterClass(true));
        }

        if (level === "busType") {
            self.filterBusinessTypeBadgeClass(GetBadgeFilterClass(true));
        }
    }


    self.showFilterSelection = function() {
        if (self.isFilterSelectionLoaded()) {
            self.isFilterSelectionLoaded(false);
        } else {
            self.isFilterSelectionLoaded(true);
        }
       
    }

    self.saveFilter = function (expandCollapse) {

        self.spinnerVisible(true);
        if (expandCollapse) {
            self.showFilterSelection();
        }

        //query for guides using filters
        $.ajax({
            type: "Post",
            url: $("#searchGuidesUrl").val(),
            data: {
                selectedCountry: self.selectedCountry(),
                selectedBusinessType: self.selectedBusinessType(),
                selectedStandard: self.selectedStandard()
            },
            datatype: "json"
        })
        .done(function (result) {
            try {
                self.guides([]);

                $.each(result.AllGuides, function (index, guideModel) {
                    var guideKo = new BuildGuide(guideModel, self);

                    if (guideKo.selectedBusinessType === self.selectedBusinessType()) {
                        guideKo.businessTypeBadgeClass(GetBadgeBusinessTypeClass(true));
                    }

                    if (guideKo.selectedStandard === self.selectedStandard()) {
                        guideKo.standardBadgeClass(GetBadgeClass(true));
                    }

                    $.each(guideKo.selectedGuideCountries, function (index, countryKo) {
                        countryKo.countryBadgeClass(GetBadgeCountryClass(false));

                        if (countryKo.value === self.selectedCountry()) {
                            countryKo.countryBadgeClass(GetBadgeCountryClass(true));
                        }
                    });

                    self.guides.push(guideKo);
                });
            } catch (e) {
                self.errorMessage($("#GuideSearchErrorMsg").val());
                $("#errorModal").modal("show");
            } 
        })
        .fail(function (result) {
            self.errorMessage($("#GuideSearchErrorMsg").val());
            $("#errorModal").modal("show");
        })
        .always(function (result) {
            self.spinnerVisible(false);
            self.isFilterLoading(false);
        });
    }

    self.saveFilter(false);
    self.isLoaded(true);
}


function BuildGuide(guideModel, rootKo) {
    var self = this;
    self.guideId = guideModel.GuideId;
    self.responseGuideId = guideModel.SelectedResponseGuide;
    self.hasResponseGuide = self.resposneGuideId !== null && self.responseGuideId !== 0;

    self.selectedBusinessTypeDesc = guideModel.SelectedBusinessTypeDesc;
    self.selectedBusinessType = guideModel.SelectedBusinessType;
    self.selectedStandard = guideModel.SelectedStandard;
    self.selectedVersion = guideModel.SelectedVersion;
    self.selectedDocument = guideModel.SelectedDocument;
    self.selectedUsageDesc = guideModel.SelectedUsageDesc;
    self.selectedUsage = guideModel.SelectedUsage;
    self.selectedDocumentFlow = guideModel.SelectedDocumentFlow;
    self.selectedDocumentFlowDesc = ko.observable("");
    self.selectedGuideCountries = [];
    self.majorUpdateDate = ko.observable(guideModel.MajorUpdateDate === null || guideModel.MajorUpdateDate === "" ? "" : moment(guideModel.MajorUpdateDate).format("YYYY-MM-DD"));
    self.majorResponseUpdateDate = ko.observable(guideModel.MajorResponseUpdateDate === null || guideModel.MajorResponseUpdateDate === ""? "" : moment(guideModel.MajorResponseUpdateDate).format("YYYY-MM-DD"));
    self.showMajorModifyDate = guideModel.ShowMajorModifyDate;
    self.showMajorResponseModifyDate = guideModel.ShowMajorResponseModifyDate;

    self.businessTypeBadgeClass = ko.observable(GetBadgeBusinessTypeClass(false));
    self.standardBadgeClass = ko.observable(GetBadgeClass(false));
    self.versionBadgeClass = ko.observable(GetBadgeClass(false));
    self.documentBadgeClass = ko.observable(GetBadgeClass(false));
    self.usageBadgeClass = ko.observable(GetBadgeClass(false));

    if (self.selectedDocumentFlow === "FROMWALMART") {
        self.selectedDocumentFlowDesc($("#ChooseDocumentFlowFromWalmartLbl").val());
    } else if (self.selectedDocumentFlow === "TOWALMART") {
        self.selectedDocumentFlowDesc($("#ChooseDocumentFlowToWalmartLbl").val());
    } else if (self.selectedDocumentFlow === "BIDIRECTION") {
        self.selectedDocumentFlowDesc($("#ChooseDocumentFlowBiDirectionLbl").val());
    }

    $.each(guideModel.SelectedCountries, function (index, countryModel) {
        var tempCountry;
        if (countryModel === "ZZ") {
            tempCountry = new BuildCountryObject($("#globalTrans").val(), countryModel);
        } else {
            tempCountry = new BuildCountryObject(countryModel, countryModel);
        }

        if (countryModel === rootKo.selectedCountry()) {
            tempCountry.countryBadgeClass(GetBadgeCountryClass(true));
        }

        self.selectedGuideCountries.push(tempCountry);

    });


    self.hrefGuide = $("#downloadUrl").val().replace("cultureTest", rootKo.selectedCulture).replace("guideIdTest", self.guideId).replace("versionTest", "release");
    self.hrefRespGuide = $("#downloadUrl").val().replace("cultureTest", rootKo.selectedCulture).replace("guideIdTest", self.responseGuideId).replace("versionTest", "release");

}

function BuildCountryObject(display, value) {
    var self = this;

    self.display = display;
    self.value = value;
    self.countryBadgeClass = ko.observable(GetBadgeCountryClass(false));
}

function GetBadgeFilterClass(isFilter) {
    if (isFilter) {
        return "badge badge-success mb-1";
    }
    return "badge badge-danger mb-1";
}

function GetBadgeBusinessTypeClass(isDefault) {
    if (isDefault) {
        return "badge badge-success mb-1";
    }
    return "badge badge-dark mb-1";
}

function GetBadgeCountryClass(isDefault) {
    if (isDefault) {
        return "badge badge-success mb-1";
    }
    return "badge badge-info mb-1";
}

//builds a generic value/display drop down option
function GenericDisplayOption(display, value) {
    var self = this;

    self.display = display;
    self.value = value;
}

function GetBadgeClass(isFilter) {
    if (isFilter) {
        return "badge badge-success mb-1";
    }
    return "badge badge-primary mb-1";
}
