﻿var KoModel = function(viewModel) {
    var self = this;

    self.allAnnouncements = ko.observableArray([]);
    self.announceId = viewModel.AnnounceId;
    self.announcementTranslations = ko.observableArray([]);
    self.attachedDocument = ko.observable({});
    self.displayLastModifiedMessage = ko.observable(viewModel.IsEdit);
    self.documentIsAttached = ko.observable(viewModel.AttachedDocument !== null);
    self.errorMessage = ko.observable("");
    self.fileUploadErrorMessage = ko.observable("");
    self.fileUploadHasError = ko.observable(false);
    self.formDataSupported = ko.observable(true);
    self.globalCultures = [];
    self.isEdit = viewModel.isEdit;
    self.isLoaded = ko.observable(false);
    self.lastModifyUserId = ko.observable(viewModel.LastModifyUserId);
    self.lastModifyTs = ko.observable(new Date(Date.parse(viewModel.LastModifyTs)));
    self.targetApps = ko.observableArray([]);
    self.selectedTargetApps = ko.observableArray([]);

    self.workActivationDate = ko.observable(viewModel.WorkActivationDate);
    self.workExpirationDate = ko.observable(viewModel.WorkExpirationDate);
    self.activationDate = ko.observable(moment(self.workActivationDate()).format("YYYY-MM-DD HH:mm"));
    self.expirationDate = ko.observable(moment(self.workExpirationDate()).format("YYYY-MM-DD HH:mm"));

    //css observables (check mark)
    self.validActivationDateClassName = ko.observable("");
    self.validAnnouncementDetailsClassName = ko.observable("");
    self.validAnnouncementDetailTranslationClassName = ko.observable("");
    self.validExpirationDateClassName = ko.observable("");
    self.validTargetAppsClassName = ko.observable("");

    //css observables (input highlight)
    self.activationDateClassName = ko.observable("");
    self.expirationDateClassName = ko.observable("");


    //tooltips
    self.displayActiveDateTooltip = ko.observable($("#DisplayActiveDateTooltipMsg").val());
    self.displayDocumentationTooltip = ko.observable($("#DisplayDocumentationTooltipMsg").val());
    self.displayExpireDateTooltip = ko.observable($("#DisplayExpireDateTooltipMsg").val());
    self.displayTargetAppsTooltip = ko.observable($("#DisplayTargetAppsTooltipMsg").val());


    //generate the translations for the app name
    if (viewModel.AnnouncementTranslations.length === 0) {
        self.announcementTranslations.push(new BuildTranslation(true, true, self, null));
    } else {
        $.each(viewModel.AnnouncementTranslations, function (index, translationModel) {
            var isFirst = translationModel.Culture === "en-us";
            self.announcementTranslations.push(new BuildTranslation(isFirst, false, self, translationModel));
        });
    }

    //load the announcement edit list
    if (viewModel.AllAnnouncements.length > 0) {
        $.each(viewModel.AllAnnouncements, function (index, allAnnounceModel) {
            self.allAnnouncements.push(new BuildNewAnnounceEditList(allAnnounceModel));
        });
        
    }

    //load any attached document info
    if (viewModel.AttachedDocument !== null) {
        self.attachedDocument(new AttachedDocumentObject(null, self, viewModel.AttachedDocument, false));
        self.documentIsAttached(true);
    }

    //contains the selected target apps (empty when adding new announcement, filled when editing)
    $.each(viewModel.SelectedTargetApps, function (index, selectedTargetAppModel) {
        self.selectedTargetApps.push(selectedTargetAppModel);
    });

    //contains the master target apps
    $.each(viewModel.TargetApps, function (index, targetAppModel) {
        self.targetApps.push(new GenericDisplayOption(targetAppModel.TargetDesc, targetAppModel.TargetRef ));
    });

    //load global cultures
    self.globalCultures.push(new GenericDisplayOption("", ""));
    $.each(viewModel.GlobalCultures, function (index, cultureModel) {
        self.globalCultures.push(new GenericDisplayOption(cultureModel, cultureModel));
    });

    //remove the translation
    self.removeAnnouncementTranslation = function (translation) {
        self.announcementTranslations.remove(translation);
    }

    //add a translation
    self.addAnnouncementTranslation = function() {
        self.announcementTranslations.push(new BuildTranslation(false, true, self, null));
    }

    //set attached document object to null
    self.removeAttachedDocument = function() {
        self.attachedDocument({});
        self.documentIsAttached(false);
    }

    self.loadAnnouncementForEdit = function (data) {
        var editUrl = $("#editAnnounceUrl").val().replace("announceIdTest", data.announceId);
        window.location = editUrl;
    }

    self.deleteAnnouncementFromDb = function(data) {
        $.ajax({
            type: "Post",
            url: $("#deletePath").val(),
            data: {
                announceId: data.announceId
            },
            datatype: "json"
        })
        .done(function (result) {
            if (result) {
                window.location = $("#addNewAnnounceUrl").val();
            } else {
                self.errorMessage($("#DeleteAnnouncementDetailsErrorMsg").val());
                $("#errorModal").modal("show");
            }
        })
        .fail(function (result) {
            self.errorMessage($("#DeleteAnnouncementDetailsErrorMsg").val());
            $("#errorModal").modal("show");
        });
    }

    self.saveAnnouncement = function() {
        $.ajax({
                type: "Post",
                url: $("#savePath").val(),
                data: {
                    announceDetails: ko.toJSON(self),
                    announceId: self.announceId
                },
                datatype: "json"
            })
            .done(function (result) {
                if (!result.HasFailure) {
                    self.lastModifyUserId(result.LastModifyUserId);
                    //have to parse it like this due to how it's passed through the JsonResult
                    self.lastModifyTs(new Date(result.LastModifyTs.match(/\d+/)[0] * 1));
                    $("#successModal").modal("toggle");
                } else {
                    self.errorMessage($("#SaveAnnouncementDetails").val());
                    $("#errorModal").modal("show");
                }
            })
            .fail(function (result) {
                self.errorMessage($("#SaveAnnouncementDetails").val());
                $("#errorModal").modal("show");
            });
    }


    //redirect to new add page
    self.addNewAnnouncement = function () {
        window.location = $("#addNewAnnounceUrl").val();
    }

    //make an input readonly
    self.readonlyInput = function (data, event) {
        return false;
    }

    //will handle the file upload converter from binary to base64 string so it can be embedded in the xml or json and verify the type and size
    if (typeof window.FormData !== "undefined") {

        self.fileUploadErrorMessage("");

        $("#fileParent").on("change", "#documentPicker", function (event) {
            var file = event.target.files[0];
            if (file) {

                $("#waitModal").modal("show");
                //set the form data
                var formData = new FormData();
                formData.append("appDocumentation", file);
                formData.append("culture", "en-us");

                $.ajax({
                    url: $("#fileHandler").val(),
                    type: "POST",
                    data: formData,
                    cache: false,
                    contentType: false,
                    processData: false
                }).done(function (result) {
                    if (result.Success) {
                        self.fileUploadHasError(false);
                        self.fileUploadErrorMessage("");
                        self.attachedDocument(new AttachedDocumentObject(file.name, self, result, true));
                        self.documentIsAttached(true);
                    } else {
                        self.fileUploadHasError(true);

                        if (result.Reason === "WrongType") {
                            self.fileUploadErrorMessage($("#WrongTypeMsg").val());
                        } else if (result.Reason === "ToLarge") {
                            self.fileUploadErrorMessage($("#ToLargeMsg").val());
                        } else if (result.Reason === "FileMissing") {
                            self.fileUploadErrorMessage($("#FileMissingMsg").val());
                        } else if (result.Reason === "MissingCulture") {
                            self.fileUploadErrorMessage($("#MissingCultureMsg").val());
                        }

                    }
                }).fail(function (result) {
                    self.fileUploadHasError(true);
                    self.fileUploadErrorMessage($("#ErrorUploadingFileLbl").val());
                }).always(function () {
                    $("#waitModal").modal("hide");
                    event.target.files = null;

                    $("#documentPicker").remove();
                    $("#fileParent").prepend('<input type="file" id="documentPicker" name="file" />');
                });
            };
        });

    } else if (typeof window.FormData === "undefined") {
        self.formDataSupported(false);
        self.fileUploadErrorMessage($("#FileNotSupportedLbl").val());
        self.fileUploadHasError(true);
    }

    self.workActivationDate.subscribe(function (data) {
        
        if (moment(data).isValid()) {
            self.activationDate(moment(data).format("YYYY-MM-DD HH:mm"));
        } else {
            self.activationDate("");
        }
    });

    self.workExpirationDate.subscribe(function (data) {
        if (moment(data).isValid()) {
            self.expirationDate(moment(data).format("YYYY-MM-DD HH:mm"));
        } else {
            self.expirationDate("");
        }
    });

    self.workActivationDateValid = ko.computed(function () {
        if (self.workActivationDate() === "") {
            self.activationDateClassName(GetFormClass(false));
            self.validActivationDateClassName(GetFormIconClass(false));
            return false;
        }

        if (self.workExpirationDate() !== "" && moment(self.workExpirationDate()).isBefore(moment(self.workActivationDate()))) {
            self.activationDateClassName(GetFormClass(false));
            self.validActivationDateClassName(GetFormIconClass(false));
            return false;
        }

        if (self.activationDate() === "") {
            self.activationDateClassName(GetFormClass(false));
            self.validActivationDateClassName(GetFormIconClass(false));
            return false;
        }

        self.activationDateClassName(GetFormClass(true));
        self.validActivationDateClassName(GetFormIconClass(true));
        return true;
    });

    self.workExpirationDateValid = ko.computed(function () {
        if (self.workExpirationDate() === "") {
            self.expirationDateClassName(GetFormClass(false));
            self.validExpirationDateClassName(GetFormIconClass(false));
            return false;
        }

        if (self.workActivationDate() !== "" && moment(self.workActivationDate()).isAfter(moment(self.workExpirationDate()))) {
            self.expirationDateClassName(GetFormClass(false));
            self.validExpirationDateClassName(GetFormIconClass(false));
            return false;
        }

        if (self.expirationDate() === "") {
            self.expirationDateClassName(GetFormClass(false));
            self.validExpirationDateClassName(GetFormIconClass(false));
            return false;
        }

        self.expirationDateClassName(GetFormClass(true));
        self.validExpirationDateClassName(GetFormIconClass(true));
        return true;
    });


    self.dateRangeValid = ko.computed(function () {
        if (!self.workActivationDateValid()) {
            self.validAnnouncementDetailsClassName(GetFormIconClass(false));
            return false;
        }

        if (!self.workExpirationDateValid()) {
            self.validAnnouncementDetailsClassName(GetFormIconClass(false));
            return false;
        }

        self.validAnnouncementDetailsClassName(GetFormIconClass(true));
        return true;
    });

    self.selectedTargetAppsValid = ko.computed(function () {
        if (self.selectedTargetApps().length === 0) {
            self.validTargetAppsClassName(GetFormIconClass(false));
            return false;
        }

        self.validTargetAppsClassName(GetFormIconClass(true));
        return true;
    });

    //are all of the app name translations valid?
    self.announcementTranslationsValid = ko.computed(function () {
        var translationsNotValid = jQuery.grep(self.announcementTranslations(), function (e) {
            if (!e.translationObjectValid()) {
                return true;
            }
            return false;
        });

        if (translationsNotValid.length > 0) {
            self.validAnnouncementDetailTranslationClassName(GetFormIconClass(false));
            return false;
        }

        self.validAnnouncementDetailTranslationClassName(GetFormIconClass(true));
        return true;
    });

    //is the app valid and able to save
    self.announcementValid = ko.computed(function () {

        if (!self.announcementTranslationsValid()) {
            return false;
        }

        if (!self.dateRangeValid()) {
            return false;
        }

        return true;

    });

    self.isLoaded(true);
}



//builds the translation section for each translation area
function BuildTranslation(isFirst, isManual, rootKo, translationModel) {
    var self = this;

    self.isFirst = isFirst;
    self.cultures = rootKo.globalCultures;
    self.culture = ko.observable(isManual && isFirst ? "en-us" : isManual ? "" : translationModel.Culture);
    self.isManual = ko.observable(isManual && !isFirst);
    self.announcementTitleTranslation = ko.observable(isManual ? "" : translationModel.AnnouncementTitleTranslation);
    self.announcementTranslation = ko.observable(isManual ? "" : translationModel.AnnouncementTranslation);
    self.cultureIsDuplicate = ko.observable(false);

    //statics
    self.cultureLocked = self.culture().toLowerCase() === "en-us";

    //css class names
    self.cultureClassName = ko.observable("");
    self.announcementTranslationClassName = ko.observable("");
    self.announcementTitleTranslationClassName = ko.observable("");
    self.validAnnouncementDetailTranslationClassName = ko.observable("");

    //make an input readonly
    self.inputReadonlyState = function () {
        if (!self.cultureLocked) {
            return undefined;
        } else {
            return "readonly";
        }
    }

    //this will handle the error checking for duplicate cultures
    self.culture.subscribe(function (data) {

        $.each(rootKo.announcementTranslations(), function (index, announceKo) {
            announceKo.cultureIsDuplicate(false);
        });

        var badTranslations = jQuery.grep(rootKo.announcementTranslations(), function (e) {
            return data === e.culture();
        });

        if (badTranslations !== undefined && badTranslations !== null && badTranslations.length > 1) {
            $.each(badTranslations, function (index, announceKo) {
                announceKo.cultureIsDuplicate(true);
            });
        }
    });

    //is the culture entered valid?
    self.cultureValid = ko.computed(function () {
        if ($.trim(self.culture()) === "") {
            self.cultureClassName(GetFormClass(false));
            return false;
        }

        //if entered, validate, must match xx-xx lower case only
        var m = self.culture().match(/^[a-z]{2}-[a-z]{2}$/);
        if (m === null) {
            self.cultureClassName(GetFormClass(false));
            return false;
        }

        if (self.cultureIsDuplicate()) {
            self.cultureClassName(GetFormClass(false));
            return false;
        }

        self.cultureClassName(GetFormClass(true));
        return true;

    });

    //is the entered translation valid?
    self.announcementTranslationValid = ko.computed(function () {
        if ($.trim(self.announcementTranslation()) === "") {
            self.announcementTranslationClassName(GetFormClass(false));
            return false;
        }

        self.announcementTranslationClassName(GetFormClass(true));
        return true;

    });

    //is the entered translation valid?
    self.announcementTitleTranslationValid = ko.computed(function () {
        if ($.trim(self.announcementTitleTranslation()) === "") {
            self.announcementTitleTranslationClassName(GetFormClass(false));
            return false;
        }

        self.announcementTitleTranslationClassName(GetFormClass(true));
        return true;

    });

    //is the entire translation object valid
    self.translationObjectValid = ko.computed(function () {
        if (!self.cultureValid()) {
            self.validAnnouncementDetailTranslationClassName(GetFormIconClass(false));
            return false;
        }

        if (!self.announcementTranslationValid()) {
            self.validAnnouncementDetailTranslationClassName(GetFormIconClass(false));
            return false;
        }

        if (!self.announcementTitleTranslationValid()) {
            self.validAnnouncementDetailTranslationClassName(GetFormIconClass(false));
            return false;
        }

        self.validAnnouncementDetailTranslationClassName(GetFormIconClass(true));
        return true;
    });
}

//build out the attached document object
function AttachedDocumentObject(fileName, rootKo, docModel) {
    var self = this;
    self.announceId = rootKo.announceId;
    self.base64Encoded = docModel.Base64Encoded;
    self.fileName = fileName === null ? docModel.FileName : fileName;
    self.contentType = docModel.ContentType;
    self.guid = docModel.Guid;
    self.culture = "en-us";

    if (self.announceId !== 0) {
        self.isNew = false;
    } else {
        self.isNew = true;
    }

    self.href = $("#downloadUrl").val().replace("cultureTest", self.culture).replace("idTest", self.announceId).replace("versionTest", "release");
   
}

//build the edit list
function BuildNewAnnounceEditList(announceModel) {
    var self = this;

    self.announceId = announceModel.AnnounceId;
    self.lastModifyUserId = announceModel.LastModifyUserId;
    self.lastModifyTs = announceModel.LastModifyTs;
    self.announcementTitleTranslation = announceModel.AnnouncementTitleTranslation;
}


function GenericDisplayOption(display, value) {
    var self = this;

    self.display = display;
    self.value = value;
}

//function that handles the form field validation class names
function GetFormClass(isValid) {
    if (isValid) {
        return "form-control";
    }

    return "form-control is-invalid";
}

//function that handles the form field validation icon class names
function GetFormIconClass(isValid) {
    if (isValid) {
        return "fa fa-check text-success";
    }

    return "fa fa-exclamation-triangle text-danger";
}