The images in this folder are referenced by the jqx.base.css and are used by the jqxColorPicker widget.

The images are downloaded from http://johndyer.name and are MIT Licensed.

